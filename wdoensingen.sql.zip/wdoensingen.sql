-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Erstellungszeit: 28. Okt 2014 um 20:56
-- Server Version: 5.5.32
-- PHP-Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `wdoensingen`
--
CREATE DATABASE IF NOT EXISTS `wdoensingen` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `wdoensingen`;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bills`
--

CREATE TABLE IF NOT EXISTS `bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `create_date` datetime NOT NULL,
  `print_date` datetime NOT NULL,
  `paid_date` datetime NOT NULL,
  `bill_type_id` int(11) NOT NULL,
  `bill_number` int(11) NOT NULL,
  `offerte_titel` varchar(500) DEFAULT NULL,
  `offerte_text` text NOT NULL,
  `text_bauseits` text,
  `text_konditionen` text,
  `text_lieferfrist` text,
  PRIMARY KEY (`id`),
  KEY `bill_type_id` (`bill_type_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Daten für Tabelle `bills`
--

INSERT INTO `bills` (`id`, `customer_id`, `create_date`, `print_date`, `paid_date`, `bill_type_id`, `bill_number`, `offerte_titel`, `offerte_text`, `text_bauseits`, `text_konditionen`, `text_lieferfrist`) VALUES
(1, 1, '2014-10-22 06:36:25', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 987653, NULL, '', NULL, NULL, NULL),
(2, 1, '2014-10-22 06:37:27', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 234567, NULL, '', NULL, NULL, NULL),
(3, 1, '2014-10-24 03:53:26', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 6, 7654, NULL, 'dasdasdasd', 'Ein Text zum Beschrieb der Offerte', 'Ein Text zum Beschrieb der Konditionen', 'Ein Text zum Beschrieb der Lieferfrist');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bill_positions`
--

CREATE TABLE IF NOT EXISTS `bill_positions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `price` double NOT NULL,
  `vat` tinyint(1) NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bill_id` (`bill_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Daten für Tabelle `bill_positions`
--

INSERT INTO `bill_positions` (`id`, `bill_id`, `description`, `price`, `vat`, `amount`) VALUES
(1, 1, 'sdfghjk', 1, 1, 2),
(2, 2, 'Eine Beschreibung', 2, 1, 1),
(3, 2, 'kjhgfds', 1, 0, 2),
(4, 3, 'sd', 54.55, 1, 2),
(5, 3, 'RF7 II', 5.5, 0, 1),
(6, 3, 'RF 82', 54, 0, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bill_types`
--

CREATE TABLE IF NOT EXISTS `bill_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Daten für Tabelle `bill_types`
--

INSERT INTO `bill_types` (`id`, `name`) VALUES
(1, 'Neulieferung'),
(2, 'Reparatur'),
(3, 'Serviceauftrag'),
(4, 'Kulanz'),
(5, 'Installation'),
(6, 'Offerte');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `parent_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `categories`
--

INSERT INTO `categories` (`id`, `name`, `parent_id`) VALUES
(1, 'Elac', 0),
(2, 'Klipsch', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` enum('Herr','Frau') NOT NULL,
  `firstname` varchar(500) NOT NULL,
  `lastname` varchar(500) NOT NULL,
  `street` varchar(500) NOT NULL,
  `zip` varchar(8) NOT NULL,
  `city` varchar(500) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `customers`
--

INSERT INTO `customers` (`id`, `title`, `firstname`, `lastname`, `street`, `zip`, `city`, `phone`, `mobile`, `email`) VALUES
(1, 'Herr', 'Filip', 'Hofer', 'Balsthalstr 4', '3000', 'Bern', '123456789', '123456789', 'a@b.ch'),
(2, 'Herr', 'Baschung', 'Ernst', 'Vogelsmattweg 5', '4710', 'Balsthl', '0623917654', '+49623914019', 'ernst.baschung@wdoensingen.ch');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prodid` varchar(100) NOT NULL,
  `name` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `price` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `products`
--

INSERT INTO `products` (`id`, `prodid`, `name`, `description`, `category_id`, `price`) VALUES
(1, 'I98 3er', 'RF7 II', 'Eine wahrhaft geile Box!', 2, 5.5),
(2, '', 'RF 82', 'Der kleine Teufel', 2, 54);

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `bills`
--
ALTER TABLE `bills`
  ADD CONSTRAINT `bills_ibfk_1` FOREIGN KEY (`bill_type_id`) REFERENCES `bill_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `bills_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints der Tabelle `bill_positions`
--
ALTER TABLE `bill_positions`
  ADD CONSTRAINT `bill_positions_ibfk_1` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints der Tabelle `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
